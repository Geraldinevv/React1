import React from 'react';
import './Footer';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <p>Adopta un perrito</p>
    </footer>
  );
};

export default Footer;